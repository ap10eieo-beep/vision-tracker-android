package com.example.visiontracker

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var overlay: TrackingOverlay
    private lateinit var status: TextView
    private lateinit var zoomText: TextView
    private var camera: Camera? = null
    private var selectedId: Int? = null
    private var zoom = 1f
    private val busy = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor()
    private val detector by lazy {
        val options = ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableMultipleObjects()
            .enableClassification()
            .build()
        ObjectDetection.getClient(options)
    }

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else status.text = "CAMERA PERMISSION REQUIRED"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))
        overlay = TrackingOverlay()
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(0xCC06131B.toInt())
        }
        val title = TextView(this).apply {
            text = "V I S I O N   /   T R A C K E R"
            setTextColor(Color.CYAN); textSize = 16f; typeface = Typeface.MONOSPACE
        }
        status = TextView(this).apply {
            text = "INITIALIZING CAMERA…"; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.MONOSPACE
        }
        zoomText = TextView(this).apply {
            text = "ZOOM 1.0×"; setTextColor(Color.CYAN); textSize = 12f; typeface = Typeface.MONOSPACE
        }
        panel.addView(title); panel.addView(status); panel.addView(zoomText)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val minus = Button(this).apply { text = "−"; setOnClickListener { setZoom(zoom / 1.25f) } }
        val plus = Button(this).apply { text = "+"; setOnClickListener { setZoom(zoom * 1.25f) } }
        val reset = Button(this).apply { text = "RESET"; setOnClickListener { selectedId = null; setZoom(1f); overlay.invalidate() } }
        controls.addView(minus, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(plus, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(reset, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(controls)
        val lp = FrameLayout.LayoutParams(-1, -2, Gravity.TOP)
        root.addView(panel, lp)
        setContentView(root)
        overlay.onSelect = { id ->
            selectedId = id
            overlay.selectedId = id
            overlay.invalidate()
        }
    }

    private fun setZoom(value: Float) {
        val state = camera?.cameraInfo?.zoomState?.value ?: return
        zoom = value.coerceIn(1f, state.maxZoomRatio)
        camera?.cameraControl?.setZoomRatio(zoom)
        zoomText.text = "ZOOM %.1f×".format(zoom)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(executor) { proxy ->
                val media = proxy.image
                if (media == null || !busy.compareAndSet(false, true)) { proxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                detector.process(image)
                    .addOnSuccessListener { objects ->
                        val mapped = objects.mapIndexed { index, obj ->
                            val rect = obj.boundingBox
                            val label = obj.labels.firstOrNull()?.text ?: "OBJECT"
                            val confidence = obj.labels.firstOrNull()?.confidence ?: 0f
                            TrackBox(obj.trackingId ?: (index + 1), label.uppercase(), confidence,
                                RectF(rect), image.width.toFloat(), image.height.toFloat())
                        }
                        runOnUiThread {
                            overlay.setBoxes(mapped)
                            status.text = "TRACKING ${mapped.size} OBJECT(S)  •  TAP A BOX"
                        }
                    }
                    .addOnFailureListener { runOnUiThread { status.text = "DETECTION ERROR" } }
                    .addOnCompleteListener { busy.set(false); proxy.close() }
            }
            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
                status.text = "CAMERA ONLINE • ON-DEVICE AI"
            } catch (e: Exception) { status.text = "CAMERA START FAILED" }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        detector.close()
        executor.shutdown()
    }

    data class TrackBox(val id: Int, val label: String, val confidence: Float, val rect: RectF, val imageW: Float, val imageH: Float)

    inner class TrackingOverlay : View(this) {
        private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.CYAN; style = Paint.Style.STROKE; strokeWidth = 3f }
        private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 5f }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 30f; typeface = Typeface.MONOSPACE }
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC001018.toInt() }
        private var boxes: List<TrackBox> = emptyList()
        var selectedId: Int? = null
        var onSelect: ((Int) -> Unit)? = null

        fun setBoxes(value: List<TrackBox>) { boxes = value; postInvalidate() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val sx = width.toFloat() / 480f
            val sy = height.toFloat() / 640f
            boxes.forEach { b ->
                // CameraX preview is center-cropped; this simple mapping is a starter and may need device-specific calibration.
                val r = RectF(b.rect.left * width / b.imageW, b.rect.top * height / b.imageH,
                    b.rect.right * width / b.imageW, b.rect.bottom * height / b.imageH)
                val paint = if (b.id == selectedId) selectedPaint else boxPaint
                canvas.drawRect(r, paint)
                val label = "#${b.id} ${b.label}"
                val labelW = textPaint.measureText(label) + 16
                canvas.drawRect(r.left, max(0f, r.top - 38f), r.left + labelW, r.top, bgPaint)
                canvas.drawText(label, r.left + 8, max(28f, r.top - 10), textPaint)
                if (b.id == selectedId) {
                    val c = (r.left + r.right) / 2
                    val d = (r.top + r.bottom) / 2
                    canvas.drawCircle(c, d, 18f, selectedPaint)
                }
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_UP) {
                val b = boxes.minByOrNull {
                    val r = RectF(it.rect.left * width / it.imageW, it.rect.top * height / it.imageH,
                        it.rect.right * width / it.imageW, it.rect.bottom * height / it.imageH)
                    val dx = event.x - (r.left + r.right) / 2
                    val dy = event.y - (r.top + r.bottom) / 2
                    dx * dx + dy * dy
                }
                if (b != null) onSelect?.invoke(b.id)
                return true
            }
            return true
        }
    }
}
