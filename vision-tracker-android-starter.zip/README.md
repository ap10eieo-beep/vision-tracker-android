# Vision Tracker Android (starter)

Native Android prototype: CameraX live preview, on-device ML Kit object detection in stream mode, multiple object boxes, tap-to-select IDs, and manual camera zoom controls.

## Build on GitHub using only your phone
1. Create a GitHub repository named `vision-tracker-android`.
2. Upload the contents of this ZIP to the repository root (keep hidden `.github` folder).
3. Open **Actions** → **Build Android APK** → **Run workflow** (or push to `main`).
4. Open the completed workflow run → **Artifacts** → download `VisionTracker-debug-apk`.
5. Extract the artifact ZIP and install `app-debug.apk`. You may need to allow installs from your browser/file manager.

## Important limitations of this starter
- This is a first runnable prototype, not a pixel-perfect clone of Panopticore.
- ML Kit provides on-device object detection and tracking IDs in stream mode, but supported labels and tracking quality depend on the model and scene.
- Zoom controls are manual; true automatic zoom-follow needs additional smoothing and camera framing logic.
- Overlay coordinate mapping is a basic implementation and may need calibration for camera crop/rotation on the target phone.
- Build has not been run in this environment. If GitHub Actions reports a build error, share the log and it can be fixed.
